package com.mandrake.editor;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
